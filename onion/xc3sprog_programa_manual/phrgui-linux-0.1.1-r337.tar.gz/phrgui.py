#!/usr/bin/env python
# -*- coding: utf-8 -*-

import wx
import guiparent

import os           # se usa para el dialogo de abrir fichero
import subprocess   # para interactuar con el shell
import thread       # to prevent gui blocking
from sys import platform as _platform  # para detectar el sistema operativo


class phrgui (guiparent.guiParent):
    def __init__(self, *args, **kwds):
        guiparent.guiParent.__init__(self, *args, **kwds)
        self.__set_extra_properties()


    def __set_extra_properties(self):
        # Definicion de la fuente monospace
        font1 = self.text_ctrl_console.GetFont()
        font1 = wx.Font(font1.GetPointSize(), wx.TELETYPE,
                   font1.GetStyle(),
                   font1.GetWeight(), font1.GetUnderlined())
                   
        # Propiedades de la consola
        self.text_ctrl_console.SetFont(font1)
        self.text_ctrl_console.SetValue("PHR>>> ")
        
        # Propiedades de la la lista de dispositivos detectados
        self.list_box_dispositivos_conectados.SetFont(font1)


    def menu_item_ayuda_acerca_de_handler(self, event):  # wxGlade: wg_parent_class.<event_handler>
        description = u"""
PHR GUI es una interfaz gráfica que permite interactuar con 
la Plataforma de Hardware Reconfigurable (CUDAR) a través 
del software xc3sprog.

$Rev: 337 $
$Date: 2014-06-12 23:58:39 -0300 (jue 12 de jun de 2014) $
"""
        licence = """
PHR GUI is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

PHR GUI is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
See the GNU General Public License for more details. You should have 
received a copy of the GNU General Public License along with
PHR GUI; if not, write to the Free Software Foundation, Inc.,
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
"""
        info = wx.AboutDialogInfo()

        info.SetIcon(wx.Icon('grafica/phr-gui-96.png', wx.BITMAP_TYPE_PNG))
        info.SetName('PHR GUI')
        info.SetVersion('0.1.1')
        info.SetDescription(description)
        #info.SetCopyright('(C) 2014 CUDAR (UTN-FRC)')
        info.SetCopyright('2014, CUDAR (UTN-FRC)')
        info.SetWebSite('http://opencores.org/project,phr')
        #info.SetLicence(licence)
        info.AddDeveloper('Luis Guanuco, Maximiliano Quinteros.')

        wx.AboutBox(info)
        event.Skip()


    def menu_item_ayuda_hint_handler(self, event):  # wxGlade: guiParent.<event_handler>
        mensaje = u"""
Procedimiento general para utilizar este programa:

1. Conecte el programador y presione en el botón \"Detectar\". 
Se listaran los dispositivos encontrados en la cadena JTAG.
2. Seleccione el dispositivo que desea programar o configurar.
3. Elija un fichero de configuración/programación.
      *.BIT para FPGA
      *.JED para CPLD
4. Presione el botón \"Transferir\".

Considere las recomendaciones de la placa específica que esté
utilizando. 
"""
        wx.MessageBox(mensaje, 'Info', wx.OK | wx.ICON_INFORMATION)
        event.Skip()
        
        
    def boton_elegir_fichero_handler(self, event):  # wxGlade: wg_parent_class.<event_handler>
        wildcard = "Archivo BIT de Xilinx (*.bit)|*.bit|" \
                   "Archivo JEDEC para CPLD (*.jed)|*.jed|" \
                   "Todos los archivos (*.*)|*.*"
        dialog = wx.FileDialog(None, "Elija un archivo", os.getcwd(), "", wildcard, wx.OPEN)
        if dialog.ShowModal() == wx.ID_OK:
            self.text_ctrl_fichero.SetValue(dialog.GetPath())
            print "New file to transfer: " + dialog.GetPath()

        dialog.Destroy()
        event.Skip()
        

    def boton_borrar_salida_handler(self, event):  # wxGlade: wg_parent_class.<event_handler>
        self.text_ctrl_console.SetValue("PHR>>> ") # borra el contenido de la consola
        print "Console cleared"
        event.Skip()


    def before_run (self):
        # preparar entorno para los eventos de transferencia y deteccion de dispositivos
        self.boton_transferir.Disable()
        self.boton_elegir_fichero.Disable()
        self.boton_detectar.Disable()
        self.boton_borrar_salida.Disable()
        self.statusbar.SetFields(["Espere ..."])


    def after_run (self):
        # restaurar entorno 
        self.boton_transferir.Enable()
        self.boton_elegir_fichero.Enable()
        self.boton_detectar.Enable()
        self.boton_borrar_salida.Enable()
        self.statusbar.SetFields(["Listo"])


    def boton_transferir_thread(self, position):
        ## preparar entorno
        wx.CallAfter(self.before_run)

        position = str (position)        
        
        if _platform == "linux" or _platform == "linux2":
            # linux
            command = "./xc3sprog/lin/xc3sprog -v -c ftdi -p " + position + " \""+ self.text_ctrl_fichero.GetValue() + "\""  
        else:
            # windows
            subprocess.call ("copy \"" + self.text_ctrl_fichero.GetValue() + "\" fpgaFile", shell=True)
            command = "xc3sprog\\win\\xc3sprog -v -L -c ftdi -p " + position + " fpgaFile:w:0:BIT"

        wx.CallAfter(self.text_ctrl_console.AppendText, command + "\n")
        
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)


        if _platform == "linux" or _platform == "linux2":
            # linux
            for line in iter(process.stdout.readline, ''):
                wx.CallAfter(self.text_ctrl_console.AppendText, line)
            process.stdout.close()
        else:
            # Windows
            line = ''
            while True:
                out = process.stdout.read(1)
                if out == '' and process.poll() != None:
                    break
                if out != '' and out != '\x0a':
                    line = line + out
                    if out == '\x0d':
                        wx.CallAfter(self.text_ctrl_console.AppendText, line)
                        line = ''
        
        wx.CallAfter(self.text_ctrl_console.AppendText, "\nPHR>>> ")

        ## restaurar entorno 
        wx.CallAfter(self.after_run)
        
        
    def boton_transferir_handler(self, event):  # wxGlade: wg_parent_class.<event_handler>
        
        device_list_selection = self.list_box_dispositivos_conectados.GetSelections()
        
        if len (device_list_selection) > 0:
            position = device_list_selection[0]
        else:
            position = 0
        
        thread.start_new_thread(self.boton_transferir_thread, (position,))
        event.Skip()
       
        
    def boton_detectar_thread (self):
        ## preparar entorno
        wx.CallAfter(self.before_run, )
        wx.CallAfter(self.list_box_dispositivos_conectados.Clear)

        ## accion

        if _platform == "linux" or _platform == "linux2":
            # linux
	        command = "./xc3sprog/lin/xc3sprog -c ftdi"
        else:
            # windows
            command = "xc3sprog\\win\\xc3sprog -c ftdi -L -j -v"

        wx.CallAfter(self.text_ctrl_console.AppendText, command + "\n")

        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)

        for line in iter(process.stdout.readline, ''):
            # Append output to console
            wx.CallAfter(self.text_ctrl_console.AppendText, line)
            
            # If it is a JTAG device append it in list box as well
            if line.lower()[0:10] == "jtag loc.:":
                deviceStr = line.split ()
                appendStr = deviceStr[0] + " " + deviceStr[2] + ": "

                if deviceStr[5] == "Desc:":
                    appendStr += deviceStr[6] + " (ID:" + deviceStr[4] + ")"
                else:
                    appendStr += "Unknown" + " (ID:" + deviceStr[4] + ")"

                wx.CallAfter(self.list_box_dispositivos_conectados.Append, appendStr)

        process.stdout.close()

        if self.list_box_dispositivos_conectados.GetCount() >= 1:
            wx.CallAfter(self.list_box_dispositivos_conectados.SetSelection, 0)

        wx.CallAfter(self.text_ctrl_console.AppendText, "\nPHR>>> ")

        ## restaurar entorno 
        wx.CallAfter(self.after_run, )
        
        
    def boton_detectar_handler(self, event):  # wxGlade: wg_parent_class.<event_handler>
        thread.start_new_thread(self.boton_detectar_thread, ())
        event.Skip()

# end of class phrgui

if __name__ == "__main__":
    app = wx.App(False)
    frame = phrgui(None, -1, "")
    app.SetTopWindow(frame)
    frame.Show()
    app.MainLoop()
